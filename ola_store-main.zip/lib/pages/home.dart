import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:carousel_pro/carousel_pro.dart';
import 'package:http/http.dart' as http;
import 'package:ola_store/compount/cardlist.dart';
import '../compount/mydrawer.dart';

class Home extends StatefulWidget {
  State<StatefulWidget> createState() {
    return HomeState();
  }
}
class HomeState extends State<Home> {
   List<dynamic> listsearch = [] ;
   var country ;
  Future getData() async {
   var url = "http://10.0.2.2:80/ola_store/search.php" ;
   var response = await http.get(url);
   var responsebody = jsonDecode(response.body) ;
   for (int i = 0 ; i <responsebody.length ; i++) {
       listsearch.add (responsebody[i]['name']);
   }
   print(listsearch) ;
  }

   getPref()async {
     SharedPreferences preferences = await SharedPreferences.getInstance();
     country = preferences.getString("country") ; 
     print(country) ;
   }


   @override
  void initState() {
    getPref();
    getData();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return  Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      appBar: AppBar(title: Text("Home"),
        backgroundColor: Colors.pinkAccent,

        centerTitle: true,
        elevation: 6 ,
        actions: <Widget>[
          IconButton(icon: Icon(Icons.search),
              onPressed: () {
              showSearch(context: context, delegate: DataSearch(list: listsearch));
      })
         ],
      ),
      drawer: MyDrawer () ,

      body: ListView(children: <Widget>[

        Container(
          height: 200.0,
          width: double.infinity,

          //         [CAROUSEL]        \\

          child: Carousel(
            images: [
              AssetImage('images/slider/lolo2.jpg'),
              AssetImage('images/slider/lolo3.png'),
              AssetImage('images/slider/lolo4.jpg'),

              //   [SLIDERS PROGRAMMING]   \\
            ],
            dotSize:10,
            dotIncreaseSize:2 ,
            dotSpacing :25,
            dotColor:Colors.white,
            //  dotBgColor:Colors.redAccent.withOpacity(0.2),
            //  showIndicator:false,
            indicatorBgPadding:20,
            boxFit :BoxFit.cover,
            overlayShadow:true,
            overlayShadowColors: Colors.blue,
            overlayShadowSize: 0.2,
            //     [END SLIDERS PROGRAMMING]   \\



          ),
        ),

        //    [END CAROUSEL]     \\

        //     [START CATEGORY]   \\

        Container(padding:EdgeInsets.all(5) , child: Text("الأقسام" , style: TextStyle(fontSize: 20 ,color:Colors.red)),),

        Container(height: 130 , child: ListView(
          scrollDirection: Axis.horizontal,
          children: <Widget>[
            Container(
                height:180,
                width:180,
                child: ListTile(
                  title:Image.asset('images/category/icon1.jpg' , width:100, height:100,),
                  subtitle:Container( child:Text("ps5",textAlign:TextAlign.center,)),
                )),
            Container(
                height:180,
                width:180,
                child: ListTile(
                  title:Image.asset('images/category/icon2.png' , width:100, height:100,),
                  subtitle:Container(child:Text("gaming chair",textAlign:TextAlign.center,)),
                )),
            Container(
                height:180,
                width:180,
                child: ListTile(
                  title:Image.asset('images/category/icon3.jpg' , width:100, height:100,),
                  subtitle:Container(child:Text("graphic cards",textAlign:TextAlign.center,)),
                )),
            Container(
                height:180,
                width:180,
                child: ListTile(
                  title:Image.asset('images/category/icon4.jpg' , width:100, height:100,),
                  subtitle:Container(child:Text("gaming headphone",textAlign:TextAlign.center,)),
                ))
          ],)),
        Container(padding:EdgeInsets.all(5) , child: Text("أخر المنتجات" , style: TextStyle(fontSize: 20 ,color:Colors.red)),),

        //     [START LATESET PRODUCTS]     \\

        Container(height: 400
          ,child: GridView(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
            children: <Widget>[

              InkWell(child: GridTile(child: Image.asset("images/lateset,products/ps5,1.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("ps5 price : 500\$", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("ps5");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/ps5,trigger.jpg", width:120, height:120, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("ps5,trigger", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("ps5,trigger");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/garphic,card/rtx2080ti,rgp.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("rtx2080ti rgb", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("rtx2080ti rgb");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/garphic,card/rtx2080ti.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("rtx2080ti", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("rtx2080ti");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/garphic,card/rtx2080,withe.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("rtx2080 white", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("rtx2080 withe");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/garphic,card/gtx1060,withe.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("gtx1060 whtie", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("gtx1060 whtie");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/garphic,card/gtx980ti.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("gtx980ti", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("gtx980ti");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/garphic,card/rtx3080,2.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("rtx3080", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("rtx3080");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/prossesor/i9.png", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("i9", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("i9");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/prossesor/i9,exterem.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("i9 exterem", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("i9 exterem");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/prossesor/i7,th10,2.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("i7 th10 ", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("i7 th10");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/prossesor/rayzen9,1.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("rayzen9 ", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("rayzen9 1");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/prossesor/i3,1.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("i3 ", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("i3 ");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/prossesor/rayzen5,1.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("rayzen5 ", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("rayzen5");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/prossesor/rayzen3.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("rayzen3", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("rayzen3");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/case/case5.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("rgb case", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("rgb case");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/case/case3.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("rgb case", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("rgb case");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/case/case2.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("rgb case", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("rgb case");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/case/case1.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("rgb case", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("rgb case");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/motherboard/x570,2.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("x570", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("x570");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/motherboard/crosshir3.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("crosshirviii", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("crosshirviii");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/motherboard/b550steel,legend.png", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("b550steel legend", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("b550steel,legend");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/motherboard/b550steel,legend.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("b550steel legend", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("b550steel,legend");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/motherboard/xbg,x570.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("xbgx570", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("xbgx570");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/mouse/mouse1.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("rgb mouse", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("rgb mouse");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/mouse/iron,man,mouse.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("iron man mouse", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("iron man mouse");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/ram/corsair.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("corsair ram", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("corsair ram");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/ram/hyperx,ram,rgb.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("hyperx ram rgb", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("hyperx ram rgb");},),
              InkWell(child: GridTile(child: Image.asset("images/lateset,products/ram/my,favorite,ram.jpg", width:100, height:100, ),footer:Container(height:20 ,  color: Colors.black.withOpacity(0.9),child:Text("rgb ram", style: TextStyle(color:Colors.red) , textAlign: TextAlign.center,),),),onTap: (){print("rgb ram");},),

            ],
          ),)


        //     [END LATESET PRODUCTS]     \\

        //   [END CATEGORY]   \\

      ],),

    ),);
  }
}

class DataSearch extends SearchDelegate<String> {
   List<dynamic> list ;
   DataSearch({this.list}) ;
   Future getsearchdata() async {
     var url = "http://10.0.2.2:80/ola_Store/searchmob.php" ;
     var data = {"searchcard" : query} ;
     var response = await http.post(url,body: data) ;
     var responsebody = jsonDecode(response.body) ;
     return responsebody ;
   }
  @override
  List<Widget> buildActions(BuildContext context) {
    // Action for appBar
    return [
      IconButton(onPressed:() {
        query = "" ;
      }, icon: Icon(Icons.clear),)
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    // Icon Leading
    return IconButton(onPressed: () {close(context, null);}, icon: Icon(Icons.arrow_back),);
  }

  @override
  Widget buildResults(BuildContext context) {
    // Results
    return FutureBuilder(
      future: getsearchdata(),
      builder: (BuildContext context, AsyncSnapshot snapshot) {
        if (snapshot.hasData) {
          return ListView.builder(itemCount: snapshot.data.length ,itemBuilder: (context , i ) {
          return Cardlist(
          name: snapshot.data[i]['name'],
          model: snapshot.data[i]['model'],
          pciExpress: snapshot.data[i]['pciExpress'],
          cores: snapshot.data[i]['cores'],
          fans: snapshot.data[i]['fans'],
          price_eg: snapshot.data[i]['price_eg'],
          price_sa: snapshot.data[i]['price_sa'],
          price_sy: snapshot.data[i]['price_sy'],
          memory: snapshot.data[i]['memory'],
          POWER_CONNECTORS: snapshot.data[i]['POWER CONNECTORS'],
          Memory_Capacity: snapshot.data[i]['Memory_Capacity'],
          StramProcessors: snapshot.data[i]['ALUS/StramProcessors'],
          Peak_FP32_Compute: snapshot.data[i]['Peak_FP32_Compute'],
          Texture_Units: snapshot.data[i]['Texture_Units'],
          ROPs: snapshot.data[i]['ROPs'],
          Base_Clock_Rate: snapshot.data[i]['Base_Clock_Rate'],
          Nvidia_Boost: snapshot.data[i]['Nvidia_Boost'],
          AMD_Boost_Rate: snapshot.data[i]['AMD_Boost_Rate'],
          Memory_Bus: snapshot.data[i]['Memory_Bus'],
          Memory_Bandwidth: snapshot.data[i]['Memory_Bandwidth'],
          L2_Cache: snapshot.data[i]['L2_Cache'],
          TDB: snapshot.data[i]['TDB'],
          Transistor_Count: snapshot.data[i]['Transistor_Count'],
          Die_Size: snapshot.data[i]['Die_Size'],
          card_cat: snapshot.data[i]['card_cat'],
          );

          });
        }
        return Center(child:CircularProgressIndicator()) ;
      },
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    // show when someone searches for something
    var searchlist  = query.isEmpty ? list : list.where((p) => p.startsWith(query)).toList();
    return ListView.builder(itemCount:searchlist.length , itemBuilder: (context , i){
       return ListTile(leading: Icon(Icons.mobile_screen_share),title: Text(searchlist[i]),
       onTap: (){
         query = searchlist[i] ;
         showResults(context) ;
       },
       );
    });
  }

}