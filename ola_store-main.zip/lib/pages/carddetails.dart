import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Carddetails extends StatefulWidget {
  final name_y ;
  final model_y ;
  final pciExpress_y ;
  final cores_y ;
  final fans_y ;
  final price_eg_y;
  final price_sy_y;
  final price_sa_y;
  final memory_y ;
  final POWER_CONNECTORS_y;
  final Memory_Capacity_y;
  final StramProcessors_y;
  final Peak_FP32_Compute_y;
  final Texture_Units_y;
  final ROPs_y;
  final Base_Clock_Rate_y;
  final Nvidia_Boost_y;
  final AMD_Boost_Rate_y;
  final Memory_Bus_y;
  final Memory_Bandwidth_y;
  final L2_Cache_y;
  final TDB_y;
  final Transistor_Count_y;
  final Die_Size_y;
  final card_cat_y ;

  Carddetails({
    this.name_y,
    this.model_y,
    this.pciExpress_y,
    this.cores_y,
    this.fans_y,
    this.price_sy_y,
    this.price_sa_y,
    this.price_eg_y,
    this.memory_y,
    this.POWER_CONNECTORS_y,
    this.Memory_Capacity_y,
    this.StramProcessors_y,
    this.Peak_FP32_Compute_y,
    this.Texture_Units_y,
    this.ROPs_y,
    this.Base_Clock_Rate_y,
    this.Nvidia_Boost_y,
    this.AMD_Boost_Rate_y,
    this.Memory_Bus_y,
    this.Memory_Bandwidth_y,
    this.L2_Cache_y,
    this.TDB_y,
    this.Transistor_Count_y,
    this.Die_Size_y,
    this.card_cat_y,});

  @override
  _CarddetailsState createState() => _CarddetailsState();
}

class _CarddetailsState extends State<Carddetails> {
  @override
  Widget build(BuildContext context) {
    return Directionality(textDirection: TextDirection.ltr, child: Scaffold(
        appBar: AppBar(
          title: Text('details'),
          centerTitle: true,
        ),
        body: ListView(children: <Widget>[
          Container( height: 300, child: GridTile(child: Image.asset("images/cards/5500xt.jpg"),
              footer: Container(height: 40 , color: Colors.black.withOpacity(0.3),alignment: Alignment.center,child:Text(widget.name_y , style: TextStyle(color:Colors.white, fontSize: 20, fontWeight: FontWeight.w700),))
          ),
          ),
          //  END HEADER PAGE  \\

          Container(alignment: Alignment.topRight,padding: EdgeInsets.all(10) ,child: Text("المواصفات"  ,style: TextStyle(fontSize: 20),),),
          // START COLUMN SPECFICITION \\

          Container(
            padding: EdgeInsets.all(10),
            child: Column(children: <Widget>[
              mySpec(context , "name:",widget.name_y,Colors.red, Colors.white) ,
              mySpec(context , "POWER CONNECTORS:",widget.POWER_CONNECTORS_y,Colors.white, Colors.red) ,
              mySpec(context , "Memory Capacity :",widget.Memory_Capacity_y,Colors.red, Colors.white) ,
              mySpec(context , "ALUS/StramProcessors :",widget.StramProcessors_y,Colors.white, Colors.red) ,
              mySpec(context , "Peak FP32 Compute (Based on Typical Boost):",widget.Peak_FP32_Compute_y,Colors.red, Colors.white) ,
              mySpec(context , "Texture Units:",widget.Texture_Units_y,Colors.white, Colors.red) ,
              mySpec(context , "ROPs:",widget.ROPs_y,Colors.red, Colors.white) ,
              mySpec(context , "Base Clock Rate :",widget.Base_Clock_Rate_y,Colors.white, Colors.red) ,
              mySpec(context , "Nvidia Boost/AMD GAME Rate:",widget.Nvidia_Boost_y,Colors.red, Colors.white) ,
              mySpec(context , "AMD Boost Rate:",widget.AMD_Boost_Rate_y,Colors.white, Colors.red) ,
              mySpec(context , "Memory Bus:",widget.Memory_Bus_y,Colors.red, Colors.white) ,
              mySpec(context , "Memory Bandwidth:",widget.Memory_Bandwidth_y,Colors.white, Colors.red) ,
              mySpec(context , "L2 Cache:",widget.L2_Cache_y,Colors.red, Colors.white) ,
              mySpec(context , "TDB:",widget.TDB_y,Colors.white, Colors.red) ,
              mySpec(context , "Transistor Count:",widget.Transistor_Count_y,Colors.red, Colors.white) ,
              mySpec(context , "Die Size:",widget.Die_Size_y,Colors.white, Colors.red) ,
              Container(alignment: Alignment.topRight,padding: EdgeInsets.all(10) ,child: Text("الأسعار"  ,style: TextStyle(fontSize: 20 , color: Colors.black),),),
              mySpec(context , "Price:",widget.price_eg_y,Colors.red, Colors.white) ,
              mySpec(context , "Price:",widget.price_sa_y,Colors.red, Colors.white) ,
              mySpec(context , "Price:",widget.price_sy_y,Colors.red, Colors.white) ,


            ]
          )
          // END COLUMN SPECFICITION \\
          )
        ],
        )
    ) );
  }
}
mySpec(context, String feature , String details , Color colorbackground , Color colortext){
return Container(
  width: MediaQuery.of(context).size.width,
  padding: EdgeInsets.all(10),
  color: colorbackground,
  child: RichText(
    text: TextSpan(
      style:
        TextStyle(fontSize: 19, color: Colors.black),
      children: <TextSpan>[
        TextSpan(text: feature),
        TextSpan(
          text: details,
          style: TextStyle(color: colortext)),
        ])
    ));
}
