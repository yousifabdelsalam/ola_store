import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class choose_country extends StatefulWidget {
  @override
  _choose_countryState createState() => _choose_countryState();
}

class _choose_countryState extends State<choose_country> {
  savePref(String country)async{
      SharedPreferences preferences = await SharedPreferences.getInstance() ;
      preferences.setString("country", country) ;
      print(preferences.getString("country")) ;

  }
  getPref()async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    var country = preferences.getString("country") ;
    if (country != null) {
      Navigator.of(context).pushNamed('homepage') ;
    }
  }

  @override
  void initState() {
    getPref() ;
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Container(
    child: Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      appBar: AppBar(
        title: Text('اختر البلد الي انت  موجود فيها يلا'),
      ),
      body: Container(
        child: ListView( children: <Widget>[
        ListTile(title:Text("مصر"), onTap: (){savePref("eg");},trailing: Image.asset("images/flag/eg.png" , height: 70, width: 70,),),
        ListTile(title:Text("السعودية"), onTap: (){savePref("sa");},trailing: Image.asset("images/flag/sa.png", height: 70, width: 70,),),
        ListTile(title:Text("سوريا"), onTap: (){savePref("sy");},trailing: Image.asset("images/flag/sy.png", height: 70, width: 70,),) ,
        ],),
      ),
    ))
    );
  }
}
