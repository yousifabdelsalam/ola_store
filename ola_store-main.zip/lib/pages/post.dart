import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Post extends StatefulWidget {
  @override
  _PostState createState() => _PostState();
}

var username = "none";
var email ;

class _PostState extends State<Post> {
    getPref() async {
     SharedPreferences preferences = await SharedPreferences.getInstance();

      setState(() {
      username = preferences.getString("username");
      email = preferences.getString("email");
      });
  }
  @override
  void initState() {
    getPref() ;
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Container(
      child:Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text("الأعلانات"),
        ),
        body: ListView(children: <Widget>[

        Card(child: Column(children: <Widget>[
         ListTile(leading: CircleAvatar(child: Icon(Icons.person)),
          title:TextFormField(
          maxLength: 255,
          maxLines:10,
          minLines:1,
          decoration : InputDecoration(
          contentPadding: EdgeInsets.only(right:10),
          hintText: "أضف منتج للبيع",
          border:OutlineInputBorder(
          borderSide:BorderSide(color:Colors.grey),
          borderRadius: BorderRadius.circular(20)
          )
          ),

          )
          ),
        Row(
        children: <Widget>[
        Expanded(child: InkWell( onTap: () {} ,child: Container(
        decoration: BoxDecoration(border : Border(top : BorderSide(color: Colors.grey.withOpacity(0.2)))),
        padding:EdgeInsets.all(10),
        child: Row(
        mainAxisAlignment:MainAxisAlignment.center,
        children: <Widget>[
        Text("أضف الأعلان" , textAlign: TextAlign.center,style: TextStyle(color:Colors.grey,fontSize: 16),),
        Padding(padding: EdgeInsets.only(right: 5)),
        Icon(Icons.add_box ,color:Colors.grey)
        ],),),)),

    ],),
    ]),
    ),
        Card(child: Column(
        children: <Widget>[
          ListTile(leading: CircleAvatar(child:Icon(Icons.person),) ,
          title: Container(
          height: 20,
          margin:EdgeInsets.only(top: 10),child: Text(username),),
          isThreeLine: true,
          trailing: Icon(Icons.filter_list),
          subtitle:Text("السلام عليكم لدي كارت 3060 سوبر سوف أبيعه لأكبر سعر ")
          ),
          Divider(height:10,),
          Row(children: <Widget>[
          Expanded(child: InkWell(onTap:(){},child:Container(decoration: BoxDecoration(border: Border(left: BorderSide(color:Colors.grey,))),child:Row(mainAxisAlignment:MainAxisAlignment.center,children: <Widget>[Text("اعجاب",textAlign: TextAlign.center),
            SizedBox(height:4) , Icon(Icons.thumb_up , color: Colors.grey,),],),padding: EdgeInsets.only(top: 5,bottom:5),),),),
          Expanded(child: InkWell(onTap:(){},child:Container(child: Padding(child:Row(mainAxisAlignment:MainAxisAlignment.center,children: <Widget>[Text("تعليق",textAlign: TextAlign.center),
            SizedBox(height:4) , Icon(Icons.comment , color: Colors.grey,),],),padding: EdgeInsets.only(top: 5,bottom:5),),),

    ))]),
      Padding(padding: EdgeInsets.only(top:5))
    ])
    ),
    ])),)
    );

  }
}
