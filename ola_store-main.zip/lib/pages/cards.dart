import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert' ;
import '../compount/cardlist.dart';
class Cards extends StatefulWidget {

  @override
  _CardsState createState() => _CardsState();
}

class _CardsState extends State<Cards> {

  var country_pref ;

  Future getData() async {
    var url ="http://10.0.2.2:80/ola_store/index.php" ;
    var data = {"cat" : "1"};
    var response = await http.post(url , body: data) ;
    var responsebody = jsonDecode(response.body) ;
    return responsebody ;
  }


@override
  Widget build(BuildContext context) {
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      appBar: AppBar(
        title: Text("GRAPHIC CARDS"),
        centerTitle:true,
      ),
      body: FutureBuilder(
        future: getData(),
        builder: (BuildContext context, AsyncSnapshot snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
              itemCount: snapshot.data.length,
              itemBuilder: (context , i){
                return Cardlist(
                  country: country_pref,
                  name: snapshot.data[i]['name'],
                  model: snapshot.data[i]['model'],
                  pciExpress: snapshot.data[i]['pciExpress'],
                  cores: snapshot.data[i]['cores'],
                  fans: snapshot.data[i]['fans'],
                  price_eg: snapshot.data[i]['price_eg'],
                  price_sa: snapshot.data[i]['price_sa'],
                  price_sy: snapshot.data[i]['price_sy'],
                  memory: snapshot.data[i]['memory'],
                  POWER_CONNECTORS: snapshot.data[i]['POWER CONNECTORS'],
                  Memory_Capacity: snapshot.data[i]['Memory_Capacity'],
                  StramProcessors: snapshot.data[i]['ALUS/StramProcessors'],
                  Peak_FP32_Compute: snapshot.data[i]['Peak_FP32_Compute'],
                  Texture_Units: snapshot.data[i]['Texture_Units'],
                  ROPs: snapshot.data[i]['ROPs'],
                  Base_Clock_Rate: snapshot.data[i]['Base_Clock_Rate'],
                  Nvidia_Boost: snapshot.data[i]['Nvidia_Boost'],
                  AMD_Boost_Rate: snapshot.data[i]['AMD_Boost_Rate'],
                  Memory_Bus: snapshot.data[i]['Memory_Bus'],
                  Memory_Bandwidth: snapshot.data[i]['Memory_Bandwidth'],
                  L2_Cache: snapshot.data[i]['L2_Cache'],
                  TDB: snapshot.data[i]['TDB'],
                  Transistor_Count: snapshot.data[i]['Transistor_Count'],
                  Die_Size: snapshot.data[i]['Die_Size'],
                  card_cat: snapshot.data[i]['card_cat'],
                ) ;
              },
            );
          }
          return Center(child:CircularProgressIndicator()) ;
        },
      ),
    ));
}
  getPref()async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
   setState(() {
    country_pref = preferences.getString("country") ;
   });


  }

  @override
  void initState() {
    getPref() ;
    super.initState();
  }
}





