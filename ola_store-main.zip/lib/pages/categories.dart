import 'package:flutter/material.dart';

import '../compount/mydrawer.dart';

class Categories extends StatefulWidget {
  @override

  _CategoriesState createState() => _CategoriesState();

}

class  _CategoriesState extends State<Categories> {

  @override
  Widget build(BuildContext context) {
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      appBar: AppBar(
        title: Text("الأقسام"),
        centerTitle: true,
      ),

      drawer: MyDrawer(),

      body: GridView(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2)
        , children: <Widget>[

        //     Start Categories logo     \\

        InkWell(child: Card(child: Column(children: <Widget>[
          Expanded(child: Image.asset(
            "images/categories,logo/logo1.jpg", fit: BoxFit.cover,),),
          Container(child: Text("GRAPHIC CARDS",
            style: TextStyle(fontSize: 18, color: Colors.red),)),
        ],),),   onTap: () {
          Navigator.of(context).pushNamed("cards");
        },),


        InkWell(child: Card(child: Column(children: <Widget>[
          Expanded(child: Image.asset(
            "images/categories,logo/logo2.jpg", fit: BoxFit.cover,),),
          Container(child: Text("RAYZEN PROSSESORS",
            style: TextStyle(fontSize: 16.8, color: Colors.red),))
        ],),), onTap: () {

        },),
        InkWell(child: Card(child: Column(children: <Widget>[
          Expanded(child: Image.asset(
            "images/categories,logo/logo3.png", fit: BoxFit.cover,),),
          Container(child: Text("INTEL PROSSESORS",
            style: TextStyle(fontSize: 18, color: Colors.red),))
        ],),), onTap: () {

        },),
        InkWell(child: Card(child: Column(children: <Widget>[
          Expanded(child: Image.asset(
            "images/categories,logo/logo4.jpg", fit: BoxFit.cover,),),
          Container(child: Text(
            "COOLERS", style: TextStyle(fontSize: 18, color: Colors.red),))
        ],),), onTap: () {

        },),
        InkWell(child: Card(child: Column(children: <Widget>[
          Expanded(child: Image.asset(
            "images/categories,logo/logo5.jpg", fit: BoxFit.cover,),),
          Container(child: Text(
            "RAM", style: TextStyle(fontSize: 18, color: Colors.red),))
        ],),), onTap: () {

        },),
        InkWell(child: Card(child: Column(children: <Widget>[
          Expanded(child: Image.asset(
            "images/categories,logo/logo6.png", fit: BoxFit.cover,),),
          Container(child: Text(
            "HARD DISCKS", style: TextStyle(fontSize: 18, color: Colors.red),))
        ],),), onTap: () {

        },),
        InkWell(child: Card(child: Column(children: <Widget>[
          Expanded(child: Image.asset(
            "images/categories,logo/logo7.jpg", fit: BoxFit.cover,),),
          Container(child: Text(
            "PS OR CAMERA", style: TextStyle(fontSize: 18, color: Colors.red),))
        ],),), onTap: () {

        },),
        InkWell(child: Card(child: Column(children: <Widget>[
          Expanded(child: Image.asset(
            "images/categories,logo/logo8.jpg", fit: BoxFit.cover,),),
          Container(child: Text("MOUSE OR KEYBOARD",
            style: TextStyle(fontSize: 16.2, color: Colors.red),))
        ],),), onTap: () {

        },),
        InkWell(child: Card(child: Column(children: <Widget>[
          Expanded(child: Image.asset(
            "images/categories,logo/logo9.jpg", fit: BoxFit.cover,),),
          Container(child: Text(
            "CASES", style: TextStyle(fontSize: 18, color: Colors.red),))
        ],),), onTap: () {

        },),
        InkWell(child: Card(child: Column(children: <Widget>[
          Expanded(child: Image.asset(
            "images/categories,logo/logo10.jpg", fit: BoxFit.cover,),),
          Container(child: Text("PHONES OR LAPTOB",
            style: TextStyle(fontSize: 18, color: Colors.red),))
        ],),), onTap: () {

        },),


        //     End categories logo     \\

      ],),
    ));
  }
}

