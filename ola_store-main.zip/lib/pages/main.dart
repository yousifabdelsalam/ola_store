import 'package:flutter/material.dart';
import 'package:ola_store/pages/carddetails.dart';
import 'package:ola_store/pages/cards.dart';
import 'package:ola_store/pages/categories.dart';
import 'package:ola_store/pages/choose_country.dart';
import 'package:ola_store/pages/home.dart';
import 'package:ola_store/pages/login.dart';
import 'package:ola_store/pages/post.dart';



void main() => runApp(MyApp()) ;


class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      //Start
      title: "eng_Yousif",
      theme: ThemeData(fontFamily: 'ShipporiMinchoB1' ),
      home: choose_country(),

      routes: {
    'categories': (context) {
    return Categories();
    },
    'homepage': (context) {
    return Home();
    },
    "cards": (context) {
    return Cards() ;
    },
    'carddetails' : (context) {
    return Carddetails() ;
    },
    'choose_country' : (context) {
    return choose_country() ;
    },
    'login': (context) {
    return Login();
    },
    'post': (context) {
    return Post();
    },
    //End
    }
    );

  }
}

