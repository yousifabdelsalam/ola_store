import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
class Login extends StatefulWidget {
  @override
  _LoginState createState() => _LoginState();
}
showloading(context) {
  return showDialog(context: context, builder: (context){
     return AlertDialog(content:Row(children: <Widget>[ Text("Loading ..."),CircularProgressIndicator()],)) ;
  });
}
showdialogall(context , String mytitle , String mycontent) {
  return showDialog(context: context, builder: (context){
    return AlertDialog(title:Text(mytitle) , content:Text(mycontent) , actions: <Widget>[
      FlatButton(child: Text("done"), onPressed:(){Navigator.of(context).pop();},) ,
    ],) ;
  });
}

class _LoginState extends State<Login> {
  Pattern pattern =
      r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';

  //Start Form Controller \\

  TextEditingController username = new TextEditingController();
  TextEditingController email = new TextEditingController();
  TextEditingController password = new TextEditingController();
  TextEditingController confirmpass = new TextEditingController();
  GlobalKey<FormState> formstatesignin = new GlobalKey<FormState>() ;
  GlobalKey<FormState> formstatesignup = new GlobalKey<FormState>() ;


  savePref(String username , String email)async{
    SharedPreferences preferences = await SharedPreferences.getInstance() ;
    preferences.setString("username", username) ;
    preferences.setString("email", email) ;
    print(preferences.getString("username")) ;
    print(preferences.getString("email")) ;

  }


String validglobal (String val) {
   if (val.isEmpty) {
     return "field cant empty" ;
   }
}

  String validusername (String val) {
    if (val.trim().isEmpty) {
      return "لا يمكن أن يكون أسم المسخدم فارغ";
    }
    if (val.trim().length < 4) {
      return "لا يمكن ان يكون أسم المستخدم أقل من 4 أحرف";
    }
    if (val.trim().length > 20) {
      return "لا يمكن ان يكون أسم المستخدم أكبر من 20 حرف";
    }
   }
  String validpassword (String val) {
    if (val.trim().isEmpty) {
      return "لا يمكن أن تكون كلمة المرور فارغة";
    }
    if (val.trim().length < 6) {
      return "لا يمكن ان تكون كلمة المرور أقل من 6 رموز";
    }
    if (val.trim().length > 20) {
      return "لا يمكن ان تكون كلمة المرور أكبر من 20 رمز";
   }
  }
  String validconfirmpass (String val) {
         if (val != password.text) {
           return "كلمة المرور غير متطابقة" ;
   }
  }

  String validemail (String val) {
    if (val.trim().isEmpty) {
      return "لا يمكن أن يكون البريد الألكتروني فارغ";
    }
    if (val.trim().length < 4) {
      return "لا يمكن ان يكون البريد الألكتروني أقل من 4 أحرف";
    }
    if (val.trim().length > 20) {
      return "لا يمكن ان يكون البريد الألكتروني أكبر من 20 حرف";
    }
    RegExp regex = new RegExp(pattern) ;
     if (!regex.hasMatch(val)) {
       return "البريد الألكتروني يجب أن يكون مثل (ola@gmail.com)";
     }
   }

  signin() async {
    var formdata = formstatesignin.currentState;
    if (formdata.validate()) {
      formdata.save();
      setState(() {
      });
      showloading(context);
      var data = {"email": email.text, "password": password.text};
      var url = "http://10.0.2.2:80/ola_store/login.php";
      var response = await http.post(url, body: data);
      var responsebody = jsonDecode(response.body);
      if (responsebody['status'] == "success") {
        savePref(responsebody['username'] , responsebody['email']) ;
        Navigator.of(context).pushNamed("homepage");
      } else {
        print("login faild");
        Navigator.of(context).pop() ;
        showdialogall(context, "خطأ", "البريد الألكتروني أو كلمة المرور خاطئة") ;

      }
    } else {
      print("not valid");
    }
  }

  signup() async{
    var formdata = formstatesignup.currentState ;
    if (formdata.validate()) {
      formdata.save () ;
      showloading(context);
      var data = {"email" : email.text, "password" : password.text,"username" : username.text} ;
      var url = "http://10.0.2.2:80/ola_store/signup.php" ;
      var response = await http.post(url , body:data) ;
      var responsebody = jsonDecode(response.body) ;
      if (responsebody['status'] == "success") {
      savePref(username.text , email.text) ;
      print("yes success") ;
      Navigator.of(context).pushNamed("homepage");
      Navigator.of(context).pop();
      }else{
      print(responsebody['status']);
      Navigator.of(context).pop() ;
      showdialogall(context, "خطأ", "البريد الألكتروني موجود سابقا") ;


      }
     }else{
      print("not valid") ;
    }
  }

  TapGestureRecognizer _changesign ;

  bool showsignin = true ;

   @override
   void initState() {
     _changesign = new TapGestureRecognizer()..onTap = (){
          setState(() {
            showsignin = !showsignin ;
          });
                  print("كلو تمام يسطا");
     } ;
     super.initState();
   }


  @override
  Widget build(BuildContext context) {
    var mdw = MediaQuery.of(context).size.width;
    return  Directionality(textDirection: TextDirection.rtl
      ,child: Scaffold(
      body: Stack(
      children: <Widget>[
      Container(height: double.infinity, width: double.infinity,),
          buildPositioned1(mdw),
        buildPositioned2(mdw),
            Container(child:SingleChildScrollView(child: Column(children: <Widget>[
            Center(child: Container(margin : EdgeInsets.only(top:30), child:Text(showsignin ?  "تسجيل الدخول" : "انشاء حساب", style: TextStyle(color: Colors.white, fontSize: 20),),)),
            Padding(padding: EdgeInsets.only(top: 33),),
             buildContainer2(mdw),
             showsignin? buildCenterIn(mdw):buildCenterUp(mdw),
             buildContainer1(mdw),

             Container(margin: EdgeInsets.only(top:10), child: RichText(
                 text: TextSpan(style: TextStyle(color: Colors.black ,fontSize: 16,fontFamily: 'ShipporiMinchoB1'), children: <TextSpan>[
                 TextSpan(text:showsignin? "في حال ليس لديك حساب يمكنك":"في حال لديك حساب يمكنك"),
                 TextSpan( recognizer: _changesign,text: showsignin? " أنشاء حساب من هنا" :" تسجيل دخول من هنا",  style:TextStyle(color:Colors.red,fontWeight: FontWeight.w800,decoration: TextDecoration.underline))
               ])
               ),
               ),
               SizedBox(height: 10 ),
              showsignin ?
              Row(children: <Widget>[
                Expanded(child: RaisedButton(
                  padding: EdgeInsets.all(10),
                  child: Row(
                  children: <Widget>[
                    Image.asset("images/social_icons/goog.png",height: 30,width: 19,) ,
                    Text(" سجل دخولك بأستخدام جوجل",style:TextStyle(fontSize: 13))
                  ],), onPressed: () {}
                  ,)),
                Expanded(child: RaisedButton(
                  padding: EdgeInsets.all(10),
                  child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Image.asset("images/social_icons/face.png",height: 30,width: 19,) ,
                    Text(" سجل دخولك بأستخدام فيسبوك",style:TextStyle(fontSize: 13))
                  ],), onPressed: () {}
                  ,))
              ],)
              :
              SizedBox(height:0)
            ],
            ),
            )
            )
      ],),));
  }
  Positioned buildPositioned2(double mdw) {
    return Positioned(
           top:300,
           right: mdw/1.5,
           child: AnimatedContainer(
           duration: Duration(milliseconds: 500),
           height: mdw,
           width: mdw,
           decoration: BoxDecoration(
           borderRadius: BorderRadius.circular(mdw),
           color: showsignin? Colors.blue[800].withOpacity(0.5):Colors.grey[800].withOpacity(0.3)
          )
          )
          );
  }

  Positioned buildPositioned1(double mdw) {
    return Positioned(
        child: Transform.scale(
        scale:1.3,
        child: Transform.translate(
        offset: Offset(0 , -mdw / 1.7),
        child: AnimatedContainer(
            duration: Duration(milliseconds: 500),
            height: mdw,
            width: mdw,
            decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(mdw),
            color: showsignin? Colors.grey[800]:Colors.blue
            )),
            ),
            ));
  }

  AnimatedContainer buildContainer2(double mdw) {
    return AnimatedContainer(
              duration:Duration(milliseconds: 500) ,
              height:100,
              width:100,
              decoration: BoxDecoration(
              color: showsignin? Colors.yellow:Colors.grey,
              borderRadius: BorderRadius.circular(100),
              boxShadow: [
              BoxShadow(color: Colors.black, blurRadius: 3, spreadRadius: 0.1),
          ]
          ),
          child: InkWell(
          onTap:(){
         setState(() {
         showsignin = !showsignin ;
         });
         },
          child: Stack
            (children: <Widget>[
          Positioned(
              top: 22,
              right: 26,
              child:  Icon(Icons.person , size: 50,color: Colors.white,
              )),
          Positioned(
              top: 35,
              left: 60,
              child: Icon(showsignin? Icons.arrow_back :Icons.arrow_forward,
                size: 30,color: Colors.white,
              )),
        ],),)
        );
  }

   Center buildCenterIn(double mdw) {
    return Center(child:
              Padding( padding:EdgeInsets.only(top: 30),
              child: AnimatedContainer(
              duration: Duration(milliseconds:600),
              curve:Curves.easeOutBack,
              height: 250,
              width: mdw/1.2,
              decoration: BoxDecoration(
              color:Colors.white,
              boxShadow: [
              BoxShadow(color: Colors.black,spreadRadius: .1, blurRadius: 2, offset: Offset(1,1))
          ]
          ),
               child: Form(
                   autovalidate: true,
                   key: formstatesignin,
               child: Container(
               margin:EdgeInsets.only(top:13) ,
               padding:EdgeInsets.all(10),
               child:SingleChildScrollView(
               child: Column(
               crossAxisAlignment:CrossAxisAlignment.start,
               children: <Widget>[
                 //  Start UserName Field  \\

               Text("البريد الألكتروني" ,style: TextStyle(fontWeight: FontWeight.w700),),
               SizedBox(height:10),

               buildTextFormField1( "أدخل البريد الألكتروني" ,false ,email , validemail),

               // End UserName Field  \\

               SizedBox(height:10),

               //  Start Password Field  \\

               Text("كلمة سر المستخدم" ,style: TextStyle(fontWeight: FontWeight.w700),),
               SizedBox(height:10),

               buildTextFormField1( "أدخل كلمة السر" ,true , password , validpassword),

          ]
         )
        )
       )
      )
     )
    )
   );
  }





        Center buildCenterUp(double mdw) {
          return Center(child:
          Padding( padding:EdgeInsets.only(top: showsignin? 40:20),
            child: AnimatedContainer(
                curve:Curves.easeInOutBack,
                duration: Duration(milliseconds:600),
                height: 403,
                width: mdw/1.2,
                decoration: BoxDecoration(
                color:Colors.white,
                boxShadow: [
                  BoxShadow(color: Colors.black,spreadRadius: .1, blurRadius: 2, offset: Offset(1,1))
                ]
            ),
          child: Form(
            key: formstatesignup,
            child: Container(
                margin:EdgeInsets.only(top:13) ,
                padding:EdgeInsets.all(10),
                child:SingleChildScrollView(
                child: Column(
                crossAxisAlignment:CrossAxisAlignment.start,
              children: <Widget>[

                //  Start UserName Field  \\

                Text("أسم المستخدم" ,style: TextStyle(fontWeight: FontWeight.w700),),
                SizedBox(height:10),

                buildTextFormField1( "أدخل أسم المستخدم" ,false ,username , validusername),

                // End UserName Field  \\

                SizedBox(height:10),

                //  Start Password Field  \\

                Text("كلمة سر المستخدم" ,style: TextStyle(fontWeight: FontWeight.w700),),
                SizedBox(height:10),

                buildTextFormField1( "أدخل كلمة السر" ,true , password , validpassword),

                //  Start User Name&pass confirm \\

                Text("تأكيد كلمة المرور" ,style: TextStyle(fontWeight: FontWeight.w700),),
                SizedBox(height:10),

                buildTextFormField1( "قم بتأكيد كلمة السر" ,true , confirmpass , validconfirmpass),

                //  Start User Email Field  \\

                Text("البريد الألكتروني" ,style: TextStyle(fontWeight: FontWeight.w700),),
                SizedBox(height:10),

                buildTextFormField1( "ادخل البريد الألكتروني" ,false, email , validemail),

                // End Password Field  \\
           ],
          )
         ),
        )
       ),
      )
     )
    );
   }

  TextFormField buildTextFormField1(String myhinttext , bool pass ,TextEditingController myController , myvalid) {
                 return TextFormField(
                    controller: myController,
                    validator: myvalid,
                    obscureText: pass,
                    decoration: InputDecoration(
                    contentPadding: EdgeInsets.all(4),
                    hintText: myhinttext,
                    filled:true,
                    fillColor: Colors.grey[200],
                    enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey[500], style: BorderStyle.solid , width:1 )
                    )
                 ),
               );
  }





  Container buildContainer1(double mdw) {
    return Container(margin: EdgeInsets.only(top: 25), child: Column(
               children: <Widget>[
             showsignin? InkWell(onTap: (){} ,child:Text("هل نسيت كلمة المرور ؟",style: TextStyle(color: Colors.black ,fontWeight:FontWeight.w700,)),) : SizedBox(),
               SizedBox(height: 10),
               RaisedButton(
               color: showsignin? Colors.blue:Colors.grey[700],
               padding: EdgeInsets.symmetric(vertical: 10 , horizontal: 10),
               onPressed: showsignin ? signin :signup ,
               child: Row(
               mainAxisAlignment:MainAxisAlignment.center,
               mainAxisSize: MainAxisSize.min,
               children: <Widget>[
               Text(showsignin ? "تسجيل الدخول" :"أنشاء حساب") , Icon(Icons.arrow_forward),
             ],))
             ],
             ),
             );
  }
}
