import 'package:flutter/material.dart';
import 'package:ola_store/pages/carddetails.dart';

class Cardlist extends StatelessWidget {
  var price ;
  final country ;
  final name ;
  final model ;
  final pciExpress ;
  final cores ;
  final fans ;
  final price_eg ;
  final price_sa ;
  final price_sy ;
  final memory ;
  final POWER_CONNECTORS;
  final Memory_Capacity;
  final StramProcessors;
  final Peak_FP32_Compute;
  final Texture_Units;
  final ROPs;
  final Base_Clock_Rate;
  final Nvidia_Boost;
  final AMD_Boost_Rate;
  final Memory_Bus;
  final Memory_Bandwidth;
  final L2_Cache;
  final TDB;
  final Transistor_Count;
  final Die_Size;
  final card_cat ;

  Cardlist({
    this.country ,
    this.name,
    this.model,
    this.pciExpress,
    this.cores,
    this.fans,
    this.price_eg,
    this.price_sa,
    this.price_sy,
    this.memory,
    this.POWER_CONNECTORS,
    this.Memory_Capacity,
    this.StramProcessors,
    this.Peak_FP32_Compute,
    this.Texture_Units,
    this.ROPs,
    this.Base_Clock_Rate,
    this.Nvidia_Boost,
    this.AMD_Boost_Rate,
    this.Memory_Bus,
    this.Memory_Bandwidth,
    this.L2_Cache,
    this.TDB,
    this.Transistor_Count,
    this.Die_Size,
    this.card_cat
  });

  @override
  Widget build(BuildContext context) {
    if (country == "sadui"){
      price = price_sa ;
    }
    if (country == "syria"){
      price = price_sy ;
    }
    if (country == "Egypt"){
      price = price_eg ;
    }
    return InkWell(
      child:Container(
        height: 258,
        width: 160,
        child: Card(
          child: Row(children: <Widget>[
            Expanded(flex:1 , child: Image.asset("images/cards/5500xt.jpg"),
            ),
            Expanded(flex:2 , child: Container( alignment: Alignment.center,height:258  ,  child:Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Text("المواصفات", style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800) , textAlign: TextAlign.center  ),

                Row(
                  children: <Widget>[
                    Expanded(child: Text("${name}" , style: TextStyle(fontSize: 18,),textAlign: TextAlign.end)) ,
                       Text(":name" , style: TextStyle(fontSize: 18,fontWeight: FontWeight.w800),textAlign: TextAlign.end) ,
                  ],),Divider(height: 10,),
                Row(
                  children: <Widget>[
                    Expanded(child: Text("${model}" , style: TextStyle(fontSize: 18,),textAlign: TextAlign.end)) ,
                        Text(":model" , style: TextStyle(fontSize: 18,fontWeight: FontWeight.w800),textAlign: TextAlign.end) ,
                  ],),
                Row(
                  children: <Widget>[
                    Expanded(child: Text("${pciExpress}" , style: TextStyle(fontSize: 18,),textAlign: TextAlign.end)) ,
                    Text(":pciExpress" , style: TextStyle(fontSize: 18,fontWeight: FontWeight.w800),textAlign: TextAlign.end),
                  ],),
                Row(
                  children: <Widget>[
                    Expanded(child: Text("${cores}" , style: TextStyle(fontSize: 18,),textAlign: TextAlign.end)) ,
                       Text(":cores" , style: TextStyle(fontSize: 18,fontWeight: FontWeight.w800),textAlign: TextAlign.end) ,
                  ],),
                Row(
                  children: <Widget>[
                    Expanded(child: Text("${fans}" , style: TextStyle(fontSize: 18,),textAlign: TextAlign.end)) ,
                       Text(":fans" , style: TextStyle(fontSize: 18,fontWeight: FontWeight.w800),textAlign: TextAlign.end)  ,
                  ],),
                Row(
                  children: <Widget>[
                    Expanded(child: Text("${memory}" , style: TextStyle(fontSize: 18,),textAlign: TextAlign.end)) ,
                    Text(":memory" , style: TextStyle(fontSize: 18,fontWeight: FontWeight.w800),textAlign: TextAlign.end) ,
                  ],),
                Row(
                  children: <Widget>[
                    Expanded(child: Text("${price}" , style: TextStyle(fontSize: 18,),textAlign: TextAlign.end)) ,
                        Text(":price" , style: TextStyle(fontSize: 18,fontWeight: FontWeight.w800),textAlign: TextAlign.end) ,
                  ],),
              ],) ),),
          ],),
        ),
      ),
      onTap:() {
        Navigator.of(context).push(MaterialPageRoute(builder: (context){
          return Carddetails(
            name_y: name,
            model_y: model,
            pciExpress_y: pciExpress,
            cores_y: cores,
            fans_y: fans,
            price_eg_y: price_eg,
            price_sy_y: price_sy,
            price_sa_y: price_sa,
            memory_y: memory,
            POWER_CONNECTORS_y: POWER_CONNECTORS,
            Memory_Capacity_y: Memory_Capacity,
            StramProcessors_y: StramProcessors,
            Peak_FP32_Compute_y: Peak_FP32_Compute,
            Texture_Units_y: Texture_Units,
            ROPs_y: ROPs,
            Base_Clock_Rate_y: Base_Clock_Rate,
            Nvidia_Boost_y: Nvidia_Boost,
            AMD_Boost_Rate_y: AMD_Boost_Rate,
            Memory_Bus_y: Memory_Bus,
            Memory_Bandwidth_y: Memory_Bandwidth,
            L2_Cache_y: L2_Cache,
            TDB_y: TDB,
            Transistor_Count_y: Transistor_Count,
            Die_Size_y: Die_Size,
            card_cat_y: card_cat,
          );
        } ));
      },
    );
  }
}

