 <?php

include "connect.php" ;

   $card =  $_POST['searchcard'] ;

   $where =  " WHERE name Like  '$card%'  "   ;

 $sql  = " SELECT * FROM cards $where   " ;
 $stmt = $con->prepare($sql);
 $stmt->execute() ;
 $cards = $stmt->fetchAll(PDO::FETCH_ASSOC) ;

 echo json_encode($cards) ;
