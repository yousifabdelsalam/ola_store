<?php

include "connect.php" ;
 $cat = $_POST['cat'] ;
 $sql  = "SELECT * FROM cards WHERE card_cat = ? " ;
 $stmt = $con->prepare($sql);
 $stmt->execute(array($cat)) ;
 $cards = $stmt->fetchAll(PDO::FETCH_ASSOC) ;

 echo json_encode($cards) ;
