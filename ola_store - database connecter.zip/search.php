 <?php

include "connect.php" ;
 
 $sql  = "SELECT * FROM cards" ;
 $stmt = $con->prepare($sql);
 $stmt->execute() ; 
 $cards = $stmt->fetchAll(PDO::FETCH_ASSOC) ;

 echo json_encode($cards) ;
